package com.EmployeeWeek8.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeWeek8Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeWeek8Application.class, args);
	}

}
