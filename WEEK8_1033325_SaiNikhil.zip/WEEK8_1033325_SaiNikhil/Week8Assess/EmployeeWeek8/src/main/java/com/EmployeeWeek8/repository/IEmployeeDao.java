package com.EmployeeWeek8.repository;

import java.util.List;

import com.EmployeeWeek8.model.Employee;

/**
 * Employee Dao interface method creation
 */
public interface IEmployeeDao {
	
	public List<Employee> getAllEmployee();

}
