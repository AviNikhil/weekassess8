package com.EmployeeWeek8.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Entity table creation
 */
@Entity
@Table(name="Employee")
public class Employee {
	@Id
	@Column(name="empid")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int empid;
	
	@Column(name="firstname")
	private String firstname;
	
	@Column(name="lastname")
	private String lastname;
	
	@Column(name="department")
	private String department;
	
	public Employee() {
		
	}
	public Employee(String firstname,String lastname,String department) {
		this.firstname=firstname;
		this.lastname=lastname;
		this.department=department;
		
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	

}
