package com.EmployeeWeek8.repository;

import java.util.List;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.EmployeeWeek8.model.Employee;
/**
 * IMPLEMENTATION OF EMPLOYEE DAO 
 */
@Repository
public class EmployeeDaoImpl implements IEmployeeDao{
	private static final Logger logger= Logger.getLogger(EmployeeDaoImpl.class);
	//logging configuration
	
	@Autowired
	private SessionFactory Sfactory;
	//session factory declaration
	public void setSfactory(SessionFactory Sfactory) {
		this.Sfactory=Sfactory;
	}

	@Override
	public List<Employee> getAllEmployee() {
		BasicConfigurator.configure();
		//session creation
		Session session=this.Sfactory.getCurrentSession();
		List<Employee> ls=session.createQuery("from Employee").list();
		return ls;
	}

}
