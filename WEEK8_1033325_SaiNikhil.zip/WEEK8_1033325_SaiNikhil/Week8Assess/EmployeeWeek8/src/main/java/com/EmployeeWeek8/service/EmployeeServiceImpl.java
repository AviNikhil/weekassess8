package com.EmployeeWeek8.service;

import java.util.List;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.EmployeeWeek8.model.Employee;
import com.EmployeeWeek8.repository.EmployeeDaoImpl;
@Service
public class EmployeeServiceImpl implements IEmployeeService{
	
	private static final Logger logger= Logger.getLogger(EmployeeServiceImpl.class);
	/**
	 * Service method implementation in layered architecture
	 */
	@Autowired
	EmployeeDaoImpl empdao = new EmployeeDaoImpl();
  ///automatic dependency
	@Override
	@Transactional
	public List<Employee> getAllEmployee() {
		BasicConfigurator.configure();
		//logger configuration
		return empdao.getAllEmployee(); //return to dao mathod
	}

}
