package com.EmployeeWeek8.controller;

import java.util.List;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.EmployeeWeek8.model.Employee;
import com.EmployeeWeek8.repository.EmployeeDaoImpl;
import com.EmployeeWeek8.service.EmployeeServiceImpl;

/**
 * Implementing rest controller 
 */
@RestController
public class EmployeeController {
	
	private static final Logger logger= Logger.getLogger(EmployeeController.class);
	@Autowired
	EmployeeServiceImpl serviceimpl=new EmployeeServiceImpl();
	//adding automatic dependency
	
    
	@RequestMapping(value = "/getAllEmployee", method = RequestMethod.GET)
	public List<Employee> getAllEmployee(){
		BasicConfigurator.configure();
		return serviceimpl.getAllEmployee(); //return to service impl method
		
	}

}
