package com.EmployeeWeek8.service;

import java.util.List;

import com.EmployeeWeek8.model.Employee;

public interface IEmployeeService {
	
	public List<Employee> getAllEmployee();

}
