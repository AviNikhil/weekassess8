package com.EmployeeWeek8.demo;

//import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeWeek8ApplicationTests {

	//@Test
	void contextLoads() {
	}

}
